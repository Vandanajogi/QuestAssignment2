package com.quest.servicetest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.quest.entity.Book;
import com.quest.repository.SpringRepository;
import com.quest.serviceimpl.SpringService;

public class SpringServiceTest {

	@InjectMocks
	SpringService service=new SpringService();
	
	@Mock
	SpringRepository springRepo;
	
	@BeforeEach
    public void setUp() throws Exception {

         MockitoAnnotations.initMocks(this);
         
    }
	@Test
	public void saveBook() {
		
		Book book=new Book();
		
	when(springRepo.save(book)).thenReturn(book);
		Book books=service.saveBook(book);
		assertNotNull(books);
		
	}
	
	 @Test
		public void getBookByidTest() {
	    	Book book= new Book();
	    	
			when(springRepo.findByBookId(1)).thenReturn(book);
			Book res=service.findBookById(1);
			assertNotNull(res);
		}
	 
	 @Test
		public void getallBookDetails() {
		 List<Book> list=new ArrayList<Book>();
			when(springRepo.findAll()).thenReturn(list);
			List<Book> res=service.getallBook();
			assertNotNull(res);
		}
	 @Test
		public void updateUserTest() {
	    	Book book= new Book();
	    	
			when(springRepo.save(book)).thenReturn(book);
			Book res=service.updateBook(book);
			assertNotNull(res);
		}
	
	    

		@Test
		public void deleteUserTest() {
		
		//when(springRepo.deleteById(1)).thenReturn("deleted");
			String users=service.deleteBook(1);
			assertEquals(users, service.deleteBook(1));
			
		}
		
		 @Test
			public void getSortedBookDetails() {
			 List<Book> list=new ArrayList<Book>();
				when(springRepo.findAll()).thenReturn(list);
				List<Book> res=service.getallSortedBook();
				assertNotNull(res);
			}
		 @Test
			public void getfilterBookBySubject() {
			 List<Book> list=new ArrayList<Book>();
				when(springRepo.findBySubject("English")).thenReturn(list);
				List<Book> res=service.getfilterBookBySubject("English");
				assertNotNull(res);
			}
		
}
