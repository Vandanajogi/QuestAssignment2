package com.quest.controllertest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.quest.controller.SpringController;
import com.quest.entity.Book;

import com.quest.serviceimpl.SpringService;


public class SpringControllerTest {
	@InjectMocks
	SpringController con=new SpringController();
	
	@Mock
	SpringService service;
	
	@BeforeEach
    public void setUp() throws Exception {

         MockitoAnnotations.initMocks(this);
         
    }
	@Test
	public void saveBook() {
		
		Book book=new Book();
		
	when(service.saveBook(book)).thenReturn(book);
		Book books=con.saveBook(book);
		assertNotNull(books);
		
	}
	
	 @Test
		public void getBookByidTest() {
	    	Book book= new Book();
	    	
			when(service.findBookById(1)).thenReturn(book);
			Book res=con.getBookById(1);
			assertNotNull(res);
		}
	 
	 @Test
		public void getallBookDetails() {
		 List<Book> list=new ArrayList<Book>();
			when(service.getallBook()).thenReturn(list);
			List<Book> res=con.getallBookDetails();
			assertNotNull(res);
		}
	 @Test
		public void updateUserTest() {
	    	Book book= new Book();
	    	
			when(service.updateBook(book)).thenReturn(book);
			Book res=con.updateBook(book);
			assertNotNull(res);
		}
	
	    

		@Test
		public void deleteUserTest() {
		
		when(service.deleteBook(1)).thenReturn("deleted");
			String users=con.delete(1);
			assertEquals(users, "deleted");
			
		}
		
		 @Test
			public void getSortedBookDetails() {
			 List<Book> list=new ArrayList<Book>();
				when(service.getallSortedBook()).thenReturn(list);
				List<Book> res=con.getSortedBookDetails();
				assertNotNull(res);
			}
		 @Test
			public void getfilterBookBySubject() {
			 List<Book> list=new ArrayList<Book>();
				when(service.getfilterBookBySubject("English")).thenReturn(list);
				List<Book> res=con.getfilterBookBySubject("English");
				assertNotNull(res);
			}
		
	
}
