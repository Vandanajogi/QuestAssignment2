package com.quest.controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.TreeSet;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.quest.entity.Book;
import com.quest.serviceimpl.SpringService;



@RestController
@RequestMapping("/library")

public class SpringController {

private static final org.slf4j.Logger log = 
		    org.slf4j.LoggerFactory.getLogger(SpringController.class);
	
	@Autowired
	private SpringService springService;
	
	@PostMapping("/save")
	public Book saveBook(@RequestBody Book book) {
		return springService.saveBook(book);
	}

	
	@GetMapping("/{id}")
	public  Book getBookById(@PathVariable("id") int bookId) {
	
		return springService.findBookById(bookId);
	
	}
	
	@GetMapping("/get")
	public List<Book> getallBookDetails() {
		return springService.getallBook();
	}
	
	
	@PutMapping("/update")
	public Book updateBook(@RequestBody Book book) {
		return springService.updateBook(book);
	}

	@DeleteMapping("/delete/{bookId}")
	public String delete(@PathVariable(value = "bookId",required = true) int bookId)
	{
		return springService.deleteBook(bookId);
	}
	
	
	
	
	
	
	@GetMapping("/getsortedbook")
	public List<Book> getSortedBookDetails() {
		List<Book> list=springService.getallSortedBook();
		  Collections.sort(list, new MySort());
		return list;
		
	}
	

	@GetMapping("/getfilterbook/{subject}")
	public List<Book> getfilterBookBySubject(@PathVariable("subject") String subject) {
		List<Book> list=springService.getfilterBookBySubject(subject);
		
		return list;
	
	}
	
	
}
