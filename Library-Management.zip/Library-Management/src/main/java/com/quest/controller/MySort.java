package com.quest.controller;

import java.util.Comparator;

import com.quest.entity.Book;

public class MySort implements Comparator<Book>  {

	@Override
	public int compare(Book arg, Book arg1) {
		// TODO Auto-generated method stub
		return (int)(arg.getBookName().compareTo(arg1.getBookName()));
	}

}
