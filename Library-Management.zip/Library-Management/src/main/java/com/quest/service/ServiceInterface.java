package com.quest.service;

import java.util.List;

import com.quest.entity.Book;



public interface ServiceInterface {
	public Book saveBook(Book book);

	public Book updateBook(Book book);

	public String deleteBook(int bookId);

	public List<Book> getallBook();
	
	//public String findBookById(int bookId);

}
