package com.quest.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.quest.entity.Book;
import com.quest.repository.SpringRepository;

import com.quest.service.ServiceInterface;

@Service
public class SpringService implements ServiceInterface {
    
	
	@Autowired
	private SpringRepository springRepository;
	

	public Book saveBook(Book book) {
		// TODO Auto-generated method stub
		return springRepository.save(book);
	}


	@Override
	public Book updateBook(Book book) {
		// TODO Auto-generated method stub
		return springRepository.save(book);
	}



	@Override
	public String deleteBook(int bookId) {
		springRepository.deleteById(bookId);
		// TODO Auto-generated method stub
		return "Successfully Deleted";
		
	}



	@Override
	public List<Book> getallBook() {
		// TODO Auto-generated method stub
		return (List<Book>) springRepository.findAll();
	}



	public List<Book> getallSortedBook() {
		// TODO Auto-generated method stub
		return (List<Book>) springRepository.findAll();
		
	}



	public List<Book> getfilterBookBySubject(String subject) {
		// TODO Auto-generated method stub
		 return springRepository.findBySubject(subject);
	}



	public Book findBookById(int bookId) {
		// TODO Auto-generated method stub
		return springRepository.findByBookId(bookId);
	}









	
}
