package com.quest.controller;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.quest.entity.IssuedBook;
import com.quest.entity.User;
import com.quest.exceptionhandler.ResourceNotFoundException;
import com.quest.serviceimpl.SpringService;
import com.quest.valueObject.Book;
import com.quest.valueObject.ResponseTemplate;



@RestController
@RequestMapping("/users")

public class SpringController {

private static final org.slf4j.Logger log = 
		    org.slf4j.LoggerFactory.getLogger(SpringController.class);
	
	@Autowired
	private SpringService springService;
	
	@Autowired
	   RestTemplate restTemplate;

	
	
	@PostMapping("/save")
	public User saveUser(@RequestBody User user) {
		
		
		return springService.saveUser(user);
	}

	

	
	@GetMapping("/getuser/{id}")
	public User getUserByID(@PathVariable("id")int userId) {
		System.out.println("inside save user");
		return springService.getUserById(userId);
		
	}
	
	
	
	@GetMapping("/getissuebook/{id}")
	public ResponseTemplate getIssueBookDetails(@PathVariable("id")int id) {
		System.out.println("inside save user");
		//ResponseTemplate res=springService.getIssueBookDetails(id);
		ResponseTemplate res=res=springService.getIssueBookDetails(id);
		//if(res == null) {
			
			//throw new ResourceNotFoundException("Exception Occured");
		//}
        return res;
		
		//return springService.getIssueBookDetails(id);
	}
	
	
	@PostMapping("/saveBook")
	public String saveBook(@RequestBody Book book) {
		return springService.saveBook(book);	
	}
	
	
	@DeleteMapping("/deleteBook/{bookId}")
		public String deleteBook(@PathVariable(value = "bookId",required = true) int bookId)
		{
			return springService.deleteBook(bookId);
		}
	
	@GetMapping("/getallbook")
	public String getallBookDetails() {
		return springService.getallBook();
	}
	
	@GetMapping("/getallsortedbook")
	public String getSortedBookDetails() {
		
		  
		return springService.getallSortedBook();
		
	}
	
	
	@PostMapping("/saveIssuedBook")
	public IssuedBook saveIssuedBook(@RequestBody IssuedBook issuedbook) {
		
		return springService.saveIssuedBook(issuedbook);
	}
	
	@GetMapping("/getAllUser")
	public List<User> getallUserDetails() {
		return springService.getallUser();
	}
	
	
	@PutMapping("/updateUser")
	public User updateUser(@RequestBody User user) {
		return springService.updateUser(user);
	}

	@DeleteMapping("/deleteUser/{userId}")
	public String deleteUser(@PathVariable(value = "userId",required = true) int userId)
	{
		
		
		return springService.deleteUser(userId);
	}
	
	@GetMapping("/filterbook/{subject}")
	public String filterBookBySubject(@PathVariable(value = "subject",required = true) String subject)
	{
		return springService.filterBookBySubject(subject);
	} 
	
}
