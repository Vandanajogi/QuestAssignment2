package com.quest.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.quest.entity.IssuedBook;


@Repository
public interface IssuedDetailRepository extends JpaRepository<IssuedBook, Integer>{

	IssuedBook findById(int id);
}
