package com.quest.service;

import java.util.List;

import com.quest.entity.User;



public interface ServiceInterface{
	public User saveUser(User user);

	public User updateUser(User user);

	public String deleteUser(int userId);

	public List<User> getallUser();
	
	public User getUserById(int userId);


}
