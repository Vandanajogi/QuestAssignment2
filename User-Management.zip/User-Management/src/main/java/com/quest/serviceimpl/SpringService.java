package com.quest.serviceimpl;


import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.quest.entity.IssuedBook;
import com.quest.entity.User;
import com.quest.repository.IssuedDetailRepository;
import com.quest.repository.SpringRepository;
import com.quest.service.ServiceInterface;
import com.quest.valueObject.Book;
import com.quest.valueObject.ResponseTemplate;

@Service
public class SpringService implements ServiceInterface {
    
	
	@Autowired
	private SpringRepository springRepository;
	
	@Autowired
	private IssuedDetailRepository issueRepo;
	
	
	
	@Autowired
	private RestTemplate restTemplate;

	public User saveUser(User user) {
		// TODO Auto-generated method stub
		return springRepository.save(user);
	}

	

	


/*
	public ResponseTemplate getUserWithBook(int userId) {
		
		ResponseTemplate res=new ResponseTemplate();
		User user=springRepository.findByUserId(userId);
		// TODO Auto-generated method stub
		Book book=restTemplate.getForObject("http://localhost:8899/library/"+user.getBookId(), Book.class);
		res.setUser(user);
		res.setBook(book);
		
		return res;
	}

*/





	public String saveBook(Book book) {
		// TODO Auto-generated method stub
		
		
		 HttpHeaders headers = new HttpHeaders();
	      headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
	      HttpEntity<Book> entity = new HttpEntity<Book>(book,headers);
	      
	      return restTemplate.exchange(
	         "http://localhost:8899/library/save", HttpMethod.POST, entity, String.class).getBody();
	   }







	public IssuedBook saveIssuedBook(IssuedBook issuedbook) {
		// TODO Auto-generated method stub
		return issueRepo.save(issuedbook);
	}







	public ResponseTemplate getIssueBookDetails(int id) {
		// TODO Auto-generated method stub
		ResponseTemplate res=new ResponseTemplate();
		IssuedBook issueBook=issueRepo.findById(id);
		User user=springRepository.findByUserId(id);
		// TODO Auto-generated method stub
		Book book=restTemplate.getForObject("http://localhost:8899/library/"+issueBook.getBookId(), Book.class);
		res.setBook(book);
	    res.setIssuedBook(issueBook);
		res.setUser(user);
		return res;
	}






	public User getUserById(int userId) {
		// TODO Auto-generated method stub
		return springRepository.findByUserId(userId);
	}






	@Override
	public User updateUser(User user) {
		// TODO Auto-generated method stub
		return springRepository.save(user);
	}






	@Override
	public String deleteUser(int userId) {
		// TODO Auto-generated method stub
		springRepository.deleteById(userId);
		return "User Successfully Deleted";
	}






	@Override
	public List<User> getallUser() {
		// TODO Auto-generated method stub
		return (List<User>) springRepository.findAll();
	}






	public String deleteBook(int bookId) {
		// TODO Auto-generated method stub
		 HttpHeaders headers = new HttpHeaders();
	      headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
	      HttpEntity<Book> entity = new HttpEntity<Book>(headers);
	      
	      return restTemplate.exchange(
	    		  "http://localhost:8899/library/delete/"+bookId, HttpMethod.DELETE, entity, String.class).getBody();
	   }






	public String getallBook() {
		// TODO Auto-generated method stub
		 HttpHeaders headers = new HttpHeaders();
	      headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
	      HttpEntity <String> entity = new HttpEntity<String>(headers);
	      
	      return restTemplate.exchange(
	    		  "http://localhost:8899/library/get", HttpMethod.GET, entity, String.class).getBody();
	   }






	public String getallSortedBook() {
		// TODO Auto-generated method stub
		HttpHeaders headers = new HttpHeaders();
	      headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
	      HttpEntity <String> entity = new HttpEntity<String>(headers);
	      
	      return restTemplate.exchange(
	    		  "http://localhost:8899/library/getsortedbook", HttpMethod.GET, entity, String.class).getBody();
	   }






	public String filterBookBySubject(String subject) {
		// TODO Auto-generated method stub
		HttpHeaders headers = new HttpHeaders();
	      headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
	      HttpEntity <String> entity = new HttpEntity<String>(headers);
	      
	      return restTemplate.exchange(
	    		  "http://localhost:8899/library/getfilterbook/"+subject, HttpMethod.GET, entity, String.class).getBody();
	}






	

	
	






	






	

	
}
