package com.quest.exceptionhandler;

import java.time.LocalDateTime;

public class ExceptionResponse {
	 private int errorCode;
	 private String message;
	   
	    
	    public String getMessage() {
	        return message;
	    }
	    public int getErrorCode() {
			return errorCode;
		}
		public void setErrorCode(int errorCode) {
			this.errorCode = errorCode;
		}
		public void setMessage(String message) {
	        this.message = message;
	    }
		public ExceptionResponse(int errorCode, String message) {
			super();
			this.errorCode = errorCode;
			this.message = message;
		}
		public ExceptionResponse() {
			super();
		}
		
	   
}
