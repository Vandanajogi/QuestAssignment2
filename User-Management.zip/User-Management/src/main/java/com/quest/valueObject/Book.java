package com.quest.valueObject;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

public class Book {
	
	private int bookId;
	private String subject;
	private String bookName;
	private String author;
	private String bookCode;
	private int price;
	private int quantity;
	
	public int getBookId() {
		return bookId;
	}
	public void setBookId(int bookId) {
		this.bookId = bookId;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getBookName() {
		return bookName;
	}
	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public String getBookCode() {
		return bookCode;
	}
	public void setBookCode(String bookCode) {
		this.bookCode = bookCode;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public Book(int bookId, String subject, String bookName, String author, String bookCode, int price, int quantity) {
		super();
		this.bookId = bookId;
		this.subject = subject;
		this.bookName = bookName;
		this.author = author;
		this.bookCode = bookCode;
		this.price = price;
		this.quantity = quantity;
	}
	public Book() {
		super();
	}
	
	


}
