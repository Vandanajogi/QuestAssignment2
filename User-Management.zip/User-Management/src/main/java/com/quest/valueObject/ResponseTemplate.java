package com.quest.valueObject;

import com.quest.entity.IssuedBook;
import com.quest.entity.User;

public class ResponseTemplate {
	private User user;
	private IssuedBook issuedBook;
	
	public IssuedBook getIssuedBook() {
		return issuedBook;
	}
	public void setIssuedBook(IssuedBook issuedBook) {
		this.issuedBook = issuedBook;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public Book getBook() {
		return book;
	}
	public void setBook(Book book) {
		this.book = book;
	}
	private Book book;
	public ResponseTemplate(User user, Book book,IssuedBook issuedBook) {
		super();
		this.user = user;
		this.book = book;
		this.issuedBook=issuedBook;
	}
	public ResponseTemplate() {
		super();
	}

}
