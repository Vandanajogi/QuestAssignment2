package com.quest.servicetest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.quest.controller.SpringController;
import com.quest.entity.IssuedBook;
import com.quest.entity.User;
import com.quest.repository.IssuedDetailRepository;
import com.quest.repository.SpringRepository;
import com.quest.serviceimpl.SpringService;
import com.quest.valueObject.Book;
import com.quest.valueObject.ResponseTemplate;



public class ServiceImplTest{
	@InjectMocks
	SpringService con=new SpringService();
	
	@Mock
	SpringRepository springRepository;
	
	@Mock
	IssuedDetailRepository issueRepo;
	
	@Mock
	RestTemplate rest;


    @BeforeEach
    public void setUp() throws Exception {

         MockitoAnnotations.initMocks(this);
      
         
    }
    @Test
   	public void saveUserTest() {
   		User user = new User();
           when(springRepository.save(user)).thenReturn(user);
           User user1=con.saveUser(user);
           assertNotNull(user1);
   	}
    
  	@Test
  	public void saveBook() {
  		
  		Book book=new Book();
  		
  		ResponseEntity<String> responseEntity = new ResponseEntity<String>("sampleBodyString", HttpStatus.ACCEPTED);
  		when(rest.exchange(
                Matchers.anyString(), 
                Matchers.any(HttpMethod.class),
                Matchers.<HttpEntity<?>> any(), 
                Matchers.<Class<String>> any()
               )
              ).thenReturn(responseEntity);
  	//when(rest.exchange("http://localhost:8899/library/save", HttpMethod.POST, entity, String.class)).thenReturn(entity);
  		String books=con.saveBook(book);
  		assertNotNull(books);
  		
  	}
    

	@Test
  	public void saveIssueBookDetailsTest() {
    	
  	IssuedBook issuebook=new IssuedBook();
  	
  		when(issueRepo.save(issuebook)).thenReturn(issuebook);
  		IssuedBook issuebooks=con.saveIssuedBook(issuebook);
  		assertNotNull(issuebooks);
  	}
	
	
	  @Test
	  	public void getIssueBookDetailsTest() {
	    	ResponseTemplate res=new ResponseTemplate();
	    	User user= new User();
	  	IssuedBook issuebook=new IssuedBook();
	  	
	  		when(issueRepo.findById(1)).thenReturn(issuebook);
	  		when(springRepository.findByUserId(1)).thenReturn(user);
	  		ResponseEntity<String> responseEntity = new ResponseEntity<String>("sampleBodyString", HttpStatus.ACCEPTED);
	  		when(rest.exchange(
	                Matchers.anyString(), 
	                Matchers.any(HttpMethod.class),
	                Matchers.<HttpEntity<?>> any(), 
	                Matchers.<Class<String>> any()
	               )
	              ).thenReturn(responseEntity);
	  		res=con.getIssueBookDetails(1);
	  		assertNotNull(res);
	  	}
	  
	   @Test
		public void getuserbyidTest() {
	    	User user= new User();
			when(springRepository.findByUserId(1)).thenReturn(user);
			User res=con.getUserById(1);
			assertNotNull(res);
		}
	
	   @Test
		public void updateUserTest() {
	    	User user= new User();
			when(springRepository.save(user)).thenReturn(user);
			User res=con.updateUser(user);
			assertNotNull(res);
		}
	   
	   @Test
		public void deleteUserTest() {
			User user= new User();
		//doNothing().when(springRepository).findById(1);
			String users=con.deleteUser(1);
			assertEquals(users, con.deleteUser(1));
			
		}
	   
	   @Test
		public void getAlluserTest() {
			List<User> list=new ArrayList<User>();
			when(springRepository.findAll()).thenReturn(list);
			List<User> res=con.getallUser();
			assertNotNull(res);
		}
	   
		@Test
	  	public void deleteBook() {
	  		
	  		Book book=new Book();
	  		
	  		ResponseEntity<String> responseEntity = new ResponseEntity<String>("sampleBodyString", HttpStatus.ACCEPTED);
	  		when(rest.exchange(
	                Matchers.anyString(), 
	                Matchers.any(HttpMethod.class),
	                Matchers.<HttpEntity<?>> any(), 
	                Matchers.<Class<String>> any()
	               )
	              ).thenReturn(responseEntity);
	  	//when(rest.exchange("http://localhost:8899/library/save", HttpMethod.POST, entity, String.class)).thenReturn(entity);
	  		String books=con.deleteBook(1);
	  		assertNotNull(books);
	  		
	  	}
		
		@Test
	  	public void getAllBook() {
	  		
	  		
	  		
	  		ResponseEntity<String> responseEntity = new ResponseEntity<String>("sampleBodyString", HttpStatus.ACCEPTED);
	  		when(rest.exchange(
	                Matchers.anyString(), 
	                Matchers.any(HttpMethod.class),
	                Matchers.<HttpEntity<?>> any(), 
	                Matchers.<Class<String>> any()
	               )
	              ).thenReturn(responseEntity);
	  	//when(rest.exchange("http://localhost:8899/library/save", HttpMethod.POST, entity, String.class)).thenReturn(entity);
	  		String books=con.getallBook();
	  		assertNotNull(books);
	  		
	  	}
		
		@Test
	  	public void getAllSortedBook() {
		ResponseEntity<String> responseEntity = new ResponseEntity<String>("sampleBodyString", HttpStatus.ACCEPTED);
  		when(rest.exchange(
                Matchers.anyString(), 
                Matchers.any(HttpMethod.class),
                Matchers.<HttpEntity<?>> any(), 
                Matchers.<Class<String>> any()
               )
              ).thenReturn(responseEntity);
  	//when(rest.exchange("http://localhost:8899/library/save", HttpMethod.POST, entity, String.class)).thenReturn(entity);
  		String books=con.getallSortedBook();
  		assertNotNull(books);
  		
  	}
		
		@Test
	  	public void getAllfilterBook() {
		ResponseEntity<String> responseEntity = new ResponseEntity<String>("sampleBodyString", HttpStatus.ACCEPTED);
  		when(rest.exchange(
                Matchers.anyString(), 
                Matchers.any(HttpMethod.class),
                Matchers.<HttpEntity<?>> any(), 
                Matchers.<Class<String>> any()
               )
              ).thenReturn(responseEntity);
  	//when(rest.exchange("http://localhost:8899/library/save", HttpMethod.POST, entity, String.class)).thenReturn(entity);
  		String books=con.filterBookBySubject("English");
  		assertNotNull(books);
  		
  	}
}
