package com.quest.controllertest;



import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.web.client.RestTemplate;

import com.quest.controller.SpringController;
import com.quest.entity.IssuedBook;
import com.quest.entity.User;
import com.quest.serviceimpl.SpringService;
import com.quest.valueObject.Book;
import com.quest.valueObject.ResponseTemplate;

public class SpringControllerTest {

	@InjectMocks
	SpringController con=new SpringController();
	
	@Mock
	SpringService service;
	
	@Mock
	RestTemplate rest;
	
	

    @BeforeEach
    public void setUp() throws Exception {

         MockitoAnnotations.initMocks(this);
         
    }
	
    @Test
	public void saveUserTest() {
		User user = new User();
        when(service.saveUser(user)).thenReturn(user);
        User user1=con.saveUser(user);
        assertNotNull(user1);
	}
	
    @Test
	public void getuserbyidTest() {
    	User user= new User();
		when(service.getUserById(1)).thenReturn(user);
		User res=con.getUserByID(1);
		assertNotNull(res);
	}
    
    @Test
  	public void getIssueBookDetailsTest() {
    	ResponseTemplate res=new ResponseTemplate();
  	IssuedBook issuebook=new IssuedBook();
  	
  		when(service.getIssueBookDetails(1)).thenReturn(res);
  		res=con.getIssueBookDetails(1);
  		assertNotNull(res);
  	}
    
    
    
	@Test
	public void saveBook() {
		
		Book book=new Book();
		
	when(service.saveBook(book)).thenReturn("inserted");
		String books=con.saveBook(book);
		assertNotNull(books);
		
	}
	@Test
	public void deleteBookTest() {
		
		Book book=new Book();
		
	when(service.deleteBook(1)).thenReturn("deleted");
		String books=con.deleteBook(1);
		assertNotNull(books);
		
	}
	
	@Test
	public void getAllBookDetailsTest() {
		
		
	when(service.getallBook()).thenReturn("found");
		String books=con.getallBookDetails();
		assertEquals(books, "found");
		
	}
	
	
	@Test
	public void getAllSortedBookTest() {
		
		
	when(service.getallSortedBook()).thenReturn("sorted");
		String books=con.getSortedBookDetails();
		assertEquals(books, "sorted");
		
	}
	
	
	
	@Test
  	public void saveIssueBookDetailsTest() {
    	
  	IssuedBook issuebook=new IssuedBook();
  	
  		when(service.saveIssuedBook(issuebook)).thenReturn(issuebook);
  		IssuedBook issuebooks=con.saveIssuedBook(issuebook);
  		assertNotNull(issuebooks);
  	}
	
	
	 @Test
		public void getAlluserTest() {
			List<User> list=new ArrayList<User>();
			when(service.getallUser()).thenReturn(list);
			List<User> res=con.getallUserDetails();
			assertNotNull(res);
		}
	 
		
	    @Test
		public void updateUserTest() {
	    	User user= new User();
			when(service.updateUser(user)).thenReturn(user);
			User res=con.updateUser(user);
			assertNotNull(res);
		}
	
	    

		@Test
		public void deleteUserTest() {
			User user= new User();
		when(service.deleteUser(1)).thenReturn("deleted");
			String users=con.deleteUser(1);
			assertEquals(users, "deleted");
			
		}
		
		@Test
		public void filterBookTest() {
			
			
		when(service.filterBookBySubject("English")).thenReturn("filtered");
			String books=con.filterBookBySubject("English");
			assertEquals(books, "filtered");
			
		}
	
}
